type TypePreload = {
  notificationApi: any;
};

declare var electronApi: TypePreload;
