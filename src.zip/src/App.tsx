import React from "react";
import "./App.scss";
import { Routers } from "./routers";

export const App = () => {
  return <Routers />;
};
