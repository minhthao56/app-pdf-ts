import React from "react";
import { Nav } from "../../components";
import "./Login.scss";

export const Login = () => {
  return (
    <div>
      <Nav />
      Login
    </div>
  );
};
